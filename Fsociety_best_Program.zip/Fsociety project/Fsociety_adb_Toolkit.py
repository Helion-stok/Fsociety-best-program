import os
import time
from colorama import Fore, Style, init
init(autoreset=True)

# === ASCII баннер ===
def banner():
    print(Fore.RED + Style.BRIGHT + """
  ______ ______  _____   _____   ______   _____  _____  __     __
 |  ____|  ____|/ ____| |  __ \ |  ____| |_   _|/ ____| \ \   / /
 | |__  | |__  | (___   | |__) || |__      | | | (___    \ \_/ / 
 |  __| |  __|  \___ \  |  ___/ |  __|     | |  \___ \    \   /  
 | |____| |____ ____) | | |     | |____   _| |_ ____) |    | |   
 |______|______|_____/  |_|     |______| |_____|_____/     |_|   
                       Fsociety Control ADB-RAT v1.0
    """)

# === Проверка подключения ADB ===
def check_device():
    os.system("adb devices")
    input(Fore.YELLOW + "\nНажми Enter для продолжения...")

# === Скриншот ===
def screenshot():
    print(Fore.CYAN + "[*] Сохраняем скриншот...")
    os.system("adb shell screencap -p /sdcard/screen.png")
    os.system("adb pull /sdcard/screen.png")
    print(Fore.GREEN + "[+] Скриншот сохранён как screen.png")

# === Установка APK ===
def install_apk():
    apk = input(Fore.YELLOW + "Введи путь к APK: ")
    os.system(f"adb install {apk}")

# === ADB-терминал ===
def adb_shell():
    while True:
        cmd = input(Fore.CYAN + "adb-shell> ")
        if cmd.lower() in ['exit', 'quit']:
            break
        os.system(f"adb shell {cmd}")

# === Удаление системы ===
def nuke_android():
    print(Fore.RED + "[!!!] ВНИМАНИЕ: Эта функция удалит /system !!!")
    confirm = input(Fore.RED + "Ты уверен? (yes/NO): ")
    if confirm.lower() == "yes":
        os.system("adb shell su -c 'rm -rf /system'")
        print(Fore.RED + "[-] /system удалён. Устройство больше не загрузится.")
    else:
        print(Fore.YELLOW + "[*] Отменено.")

# === Главное меню ===
def menu():
    while True:
        os.system("clear" if os.name != 'nt' else "cls")
        banner()
        print(Fore.CYAN + """
[1] Проверить подключение (adb devices)
[2] Сделать скриншот
[3] Установить APK
[4] Войти в ADB-оболочку
[5] Уничтожить Android (/system)
[0] Выход
""")
        choice = input(Fore.GREEN + "Выбор > ")
        
        if choice == "1":
            check_device()
        elif choice == "2":
            screenshot()
            input("Нажми Enter...")
        elif choice == "3":
            install_apk()
            input("Нажми Enter...")
        elif choice == "4":
            adb_shell()
        elif choice == "5":
            nuke_android()
            input("Нажми Enter...")
        elif choice == "0":
            print(Fore.MAGENTA + "До встречи в аду, хакер.")
            break
        else:
            print(Fore.RED + "Неверный выбор.")
            time.sleep(1)

# === Старт ===
if __name__ == "__main__":
    menu()