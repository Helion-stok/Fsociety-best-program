import socket

def main():
    print("== fsociety_ip_name ==")
    host = input("[+] Введите домен сайта (например, example.com): ")

    try:
        ip = socket.gethostbyname(host)
        print(f"[✓] IP адрес сайта {host}: {ip}")
    except socket.gaierror:
        print("[!] Не удалось определить IP. Проверь правильность домена.")

if __name__ == "__main__":
    main()